const express = require('express');
const path = require('path');
const app = express();

app.use(express.static(path.join(__dirname)));

app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));
app.get('/produto', (req, res) => res.sendFile(path.join(__dirname, 'produto.html')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Magalu Clone rodando na porta ${PORT}`));
